## License
**All rights reserved.** No use, copying, modification, or distribution is permitted.  
