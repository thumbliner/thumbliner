---
layout: default
title: License
nav_order: 99
nav_exclude: true
---

# License

_Last updated: October, 2025_

Copyright (c) 2025 SALMAN KHAN  
**All rights reserved.**

This site and repository are provided for viewing only. No permission is granted to use, copy, modify, merge, publish, distribute, sublicense, and/or sell the contents, in whole or in part.

See the full text in the repository’s [LICENSE](https://github.com/<USER>/<REPO>/blob/main/LICENSE).
