---
title: Core
nav_order: 1
---

# The Practice
_All it takes is a long attention span_  

---

<div class="urdu" lang="ur" dir="rtl">
  <div class="verses">
    <div class="misra">ہے آدمی بجائے خود اک محشرِ خیال</div>
    <div class="misra">ہم انجمن سمجھتے ہیں خلوت ہی کیوں نہ ہو</div>
    <div class="poet">— مرزا غالبؔ</div>
  </div>
</div>
